<?php
session_start();

$server = 'localhost';
$user = 'root';
$pass = '';
$bd = 'db_pizzaria';
$con = new mysqli($server, $user,$pass,$bd);

if(!$con){
	echo "Erro na conexão: ";
}

function getUsers(){
	$sql = 'SELECT cd_usuario, nm_usuario, nm_login, cd_tipo 
				FROM tb_usuario';
	$res = $GLOBALS['con']->query($sql);
	return $res;
}

function getTipoUsers(){
	$sql = 'SELECT * FROM tb_tipo_usuario';
	$res = $GLOBALS['con']->query($sql);
	return $res;
}

function delUser($id){
	$sql = 'DELETE FROM tb_usuario WHERE cd_usuario = '.$id;
	$GLOBALS['con']->query($sql);
}





function Login($usuario, $senha){
	$comando = 'SELECT * FROM tb_usuario 
				WHERE nm_login="'.$usuario
				.'" AND cd_senha="'.$senha.'"';

	//envia o comando para banco e armazena a resposta
	$resp = $GLOBALS['con']->query($comando);
	if($resp->num_rows == 1){
		$usuario = $resp->fetch_array();
		//armazenando dados na sessão
		$_SESSION['cd'] = $usuario['cd_usuario'];
		$_SESSION['nome'] = $usuario['nm_usuario'];
		$_SESSION['tipo'] = $usuario['cd_tipo'];
		//verifica o nível de acesso para poder direcionar o usuário
		if($usuario['cd_tipo'] == 2){
			//redireciona conforme o nível de acesso do usuário
			header('location: dashboard.php');
		}else{
			echo "Não é o gerente";
		}
	}else{
		echo "Usuário e/ou senha inválidos";
	}
}

function Proteger($nivel){
	//verifica se é realmente um gerente
    if($_SESSION['tipo'] != $nivel){
        //se não for, redireciona para o login
        header('location: index.php');
    }
}

function Total($deque){

	if($deque == 'usuarios'){
		$comando = 'SELECT COUNT(cd_usuario) as total FROM tb_usuario';
	}
	else if($deque == 'categorias'){
		$comando = 'SELECT COUNT(cd_categoria) as total FROM tb_categoria';
	}
	else if($deque == 'produtos'){
		$comando = 'SELECT COUNT(cd_produto) as total FROM tb_produto';
	}

	$resposta = $GLOBALS['con']->query($comando);

	$total = $resposta->fetch_array();

	echo $total['total'];
}

function addCategoria($nome){
	$comando = 'INSERT INTO tb_categoria 
					VALUES (null, "'.$nome.'")';

	$resposta = $GLOBALS['con']->query($comando);
	if($resposta){
		echo "Cadastrado com sucesso!";
	}else{
		echo "Erro ao cadastrar categoria";
	}
}

function getCategorias(){
	$comando = 'SELECT * FROM tb_categoria';
	$resposta = $GLOBALS['con']->query($comando);
	return $resposta;
}

function delCategoria($cd){
	$comando = 'DELETE FROM tb_categoria WHERE cd_categoria='.$cd;
	$resposta = $GLOBALS['con']->query($comando);
	if($resposta){
		$retorno['msg']="Excluído com sucesso!";
		//vai('categorias.php');
	}else{
		$retorno['msg']="Erro ao excluir.";
	}
	echo json_encode($retorno);
}
function vai($onde){
	echo '<script>
			window.location = "'.$onde.'";
	</script>';
}


function alert($msg){
	echo '<style>
	*{margin:0;overflow:hidden;}
.fundo{
	position: absolute;
	z-index: 99;	
	width: 100vw;
	height: 100vh;
	background-color: black;
	opacity: 0.7;
	display: block;
	overflow-x: hidden;
}
#modal{
	z-index: 99;
	width: 40vw;
	margin-left:30vw;
	margin-top:20vh;
	border-radius:1vw;
	border:1px solid black;
	display:block;
	position:absolute;
	padding: 10px;
	background-color: white;
}
#modal h1{
	margin-top:0px;
	text-align: center;
}
#modal span{
	float:right;
	padding:10px;
	background-color:gray;
	color:white;
	border-radius:100%;
	font-size:10px;
	cursor:pointer;
}
#modal button{	
	width: 5vw;	
	margin-left: 17.5vw;
}
</style>
<script>
	function fechar(){
		let fundo = document.querySelector(".fundo");
		let modal = document.querySelector("#modal");
		fundo.style.display = "none";
		modal.style.display = "none";
	}
</script>
<div class="fundo"></div>
<div id="modal">
<h1>'.$msg.'</h1>
<button class="btn btn-primary" onclick="fechar()">Ok</button>
</div>';
}

function addProduto($nome, $valor,$descricao,$foto,$cat){

	$destino = '/img/';

	$comando = 'INSERT INTO tb_produto VALUES(null,
		"'.$nome.'",'.$valor.',"'.$descricao.'","'.$foto.'",'.$cat.')';
	
	$resultado = $GLOBALS['con']->query($comando);

	$destino.= $GLOBALS['con']->insert_id.'/';

	//verificamos se não existir, criamos a pasta
	if(!is_dir($destino)){
		mkdir($destino, 0777);
	}
	
	$destino.= $foto['foto']['name'];

	if(move_uploaded_file($destino, $foto['foto']['tmp_name'])){
		alert("Cadastrado com sucesso!");
	}else{
		alert("Erro ao cadastrar");
	}
}
