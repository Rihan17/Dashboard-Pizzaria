<?php include('conexao.php'); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Conteúdo Principal -->
    <div class="container-fluid vh-100">
        <div class="row h-100 brand" style="background-color: rgb(251 250 197) !important;">
            <!-- Formulário de Login -->
            <div class="col-md-6 d-flex flex-column justify-content-center align-items-center">
                
                <form method="post" class="w-50 login">
                    <h3>Login</h3>
                    <div class="mb-3">
                        <label for="usuario" class="form-label">Usuário:</label>
                        <input type="text" class="form-control" name="usuario" placeholder="Digite seu usuário">
                    </div>
                    <div class="mb-3">
                        <label for="senha" class="form-label">Senha:</label>
                        <input type="password" class="form-control" name="senha" placeholder="Digite sua senha">
                    </div>
                    <button type="submit" class="btn btn-outline-primary w-100">Entrar</button>
                    <?php
                        if($_POST){
                            Login($_POST['usuario'],$_POST['senha']);
                        }
                    ?>
                </form>
            </div>
            <!-- Imagem/Parte Estilizada -->
            <div class="col-md-6"></div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
