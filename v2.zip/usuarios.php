<?php include('conexao.php'); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <!-- Cabeçalho -->
    <div class="container-fluid bg-light p-3">
        <div class="d-flex justify-content-between">
            <span>Olá, <strong>Rodolfo</strong>.</span>
            <button class="btn btn-light">Sair</button>
        </div>
    </div>

    <!-- Título do Dashboard -->
    <div class="container text-center my-3">
        <h2 class="text-danger">DASHBOARD</h2>
    </div>

    <!-- Conteúdo Principal -->
    <div class="container">
        <div class="row">
            <!-- Configurações -->
            <div class="col-md-3">
                <h5>Configurações</h5>
                <div class="d-grid gap-2">
                   <?php include('menu.inc'); ?>
                </div>
            </div>

            <!-- Sistema e Operações -->
            <div class="col-md-9">
                <!-- Formulário de Nova Categoria -->
                <h5>Registro de Usuário:</h5>
                <form class= mb-4" method="post">            
                    <div class="row d-flex">
                        <div class="form-group col-6 offset-1">
                            Nome:    
                            <input type="text" name="usuario" id="usuario" class="form-control me-2" placeholder="Nome do usuário">
                        </div> 

                <div class="form-group col-3">
                    Tipo:    
                    <select name="tipo" id="tipo" class="form-control me-2">
                    </select>
                </div>
                    </div>
                    <div class="row d-flex mt-3">
                        <div class="form-group col-3 offset-1">
                            Login:    
                            <input type="text" name="login" id="login" class="form-control me-2" placeholder="Login do usuário">
                        </div>
                        <div class="form-group col-3">
                            Senha:    
                            <input type="password" name="senha" id="senha" class="form-control me-2" >
                        </div>
                        <div class="form-group col-3">
                            .
                            <button type="submit" class="btn btn-outline-secondary form-control">Cadastrar</button>        
                        </div>
                    </div>                
                
                </form>
                <!-- Tabela de Categorias -->
                <h5>Registros</h5>
                <div class="row d-flex">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Cód</th>
                                <th scope="col">Nome</th>
                                <th scope="col">Login</th>
                                <th scope="col">Tipo</th>
                                <th scope="col">#Controles</th>
                            </tr>
                        </thead>
                        <tbody id="registros"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        var tipo = document.getElementById('tipo');
        var registros = document.getElementById('registros');

        carregar();

        async function carregar(){
            
            var retorno = await fetch('ajax_usuario.php?todos=tipos');
            var tipos = await retorno.json();

            var select = '<option>Selecione..</option>';
            for(var i=0; i < tipos.length; i++){
                select += '<option value='+tipos[i].cd_tipo_usuario+'>';
                select += tipos[i].nm_tipo_usuario + '</option>';
            }
            tipo.innerHTML = select;

            var retorno = await fetch('ajax_usuario.php?todos=users');
            var users = await retorno.json();

            var linhas = '';
            for(var i=0; i < users.length; i++){
                linhas += '<tr>';
                linhas += '<td>'+users[i].cd_usuario+'</td>';
                linhas += '<td>'+users[i].nm_usuario+'</td>';
                linhas += '<td>'+users[i].nm_login+'</td>';
                linhas += '<td>'+users[i].cd_tipo+'</td>';
                linhas += '<td>';
                linhas += '<button onclick="del('+users[i].cd_usuario+')">X</button>';
                linhas += '</td>';
                linhas += '</tr>';
            }     
            registros.innerHTML = linhas;       
        }

        async function del(id){
            var certeza = confirm("Tem certeza?");
            if(certeza){
                var retorno = await fetch('ajax_usuario.php?del='+id);                
                carregar();
            }            
        }
    </script>
</body>
</html>
