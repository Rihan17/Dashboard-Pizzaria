<?php 
    include('conexao.php');

    Proteger(2);

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Cabeçalho -->
    <div class="container-fluid bg-light p-3">
        <div class="d-flex justify-content-between">
            <span>Olá, <strong><?php echo $_SESSION['nome'];?></strong>.</span>
            <a href="logout.php" class="btn btn-light">Sair</a>
        </div>
    </div>

    <!-- Título do Dashboard -->
    <div class="container text-center my-3">
        <h2 class="text-danger">DASHBOARD</h2>
    </div>

    <!-- Conteúdo Principal -->
    <div class="container">
        <div class="row">
            <!-- Configurações -->
            <div class="col-md-3">
                <h5>Configurações</h5>
                <div class="d-grid gap-2">
                  <?php include('menu.inc'); ?>
                </div>
            </div>

            <!-- Sistema e Operações -->
            <div class="col-md-9">
                <!-- Sistema -->
                <h5>Sistema:</h5>
                <div class="row text-center my-3">
                    <div class="col">
                        <h1>22</h1>
                        <button class="btn btn-outline-secondary">Produtos</button>
                    </div>
                    <div class="col">
                        <h1>7</h1>
                        <button class="btn btn-outline-secondary">Categorias</button>
                    </div>
                    <div class="col">
                        <h1>
                            <?php
                                Total('usuarios');
                            ?>
                        </h1>
                        <button class="btn btn-outline-secondary">Usuários</button>
                    </div>
                </div>

                <!-- Operação -->
                <h5>Operação:</h5>
                <div class="row text-center my-3">
                    <div class="col">
                        <h1>18</h1>
                        <button class="btn btn-outline-secondary">Restaurante Fechado</button>
                    </div>
                    <div class="col">
                        <h1>51</h1>
                        <button class="btn btn-outline-secondary">Delivery Fechado</button>
                    </div>
                    <div class="col">
                        <h1>18</h1>
                        <button class="btn btn-outline-secondary">Restaurante Aberto</button>
                    </div>
                    <div class="col">
                        <h1>51</h1>
                        <button class="btn btn-outline-secondary">Delivery Aberto</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
