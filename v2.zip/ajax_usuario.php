<?php
include('conexao.php');

if(isset($_GET['todos'])){
	if($_GET['todos'] == 'users'){
		$todos = getUsers();	
		for($i=0; $i<$todos->num_rows; $i++){
			$lista[$i] = $todos->fetch_object();		
		}
		echo json_encode($lista);
	}
	else if($_GET['todos'] == 'tipos'){
		$todos = getTipoUsers();	
		for($i=0; $i<$todos->num_rows; $i++){
			$lista[$i] = $todos->fetch_object();		
		}
		echo json_encode($lista);
	}
}
if(isset($_GET['del'])){
	delUser($_GET['del']);
}