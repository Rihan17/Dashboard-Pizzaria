<?php
include('conexao.php');

if(isset($_GET['excluir'])){
    delCategoria($_GET['excluir']);        
}
else if(isset($_GET['listar'])){
     $todas = getCategorias();

     
     for($i=0; $i<$todas->num_rows; $i++){
        $resposta[$i] = $todas->fetch_object();
     }
     echo json_encode($resposta);

}

?>